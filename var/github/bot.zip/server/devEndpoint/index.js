import {init as ServerConfigInit} from './serverConfig';
import {init as LeadInit} from './lead';

export default [
  ServerConfigInit,
  LeadInit,
];
