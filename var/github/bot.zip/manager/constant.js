let constant = window.leadgenbotconst || {};
export default constant;
